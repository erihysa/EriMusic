// Copyright (c) 2017, 2020 rinukkusu, hayribakici. All rights reserved. Use of
// this source code is governed by a BSD-style license that can be found in the
// LICENSE file.

// ignore_for_file: deprecated_member_use_from_same_package

import 'dart:io';
import 'dart:convert';
import 'package:spotify/spotify.dart';

void main() async {
  final keyJson = await File('example/.apikeys').readAsString();
  final keyMap = json.decode(keyJson);

  var credentials = SpotifyApiCredentials(keyMap['id'], keyMap['secret']);
  final spotify = SpotifyApi(credentials);
  spotify.enableLogging(enable: true);

  print('\nExpannd shortened spotify link of https://spotify.link/hRkBrwub9xb');
  final longLink = await spotify.expandLink('https://spotify.link/hRkBrwub9xb');
  print(longLink);

  print('\nPodcast:');
  await spotify.shows.get('4rOoJ6Egrf8K2IrywzwOMk').then((podcast) => print(podcast.name)).onError(
        (error, stackTrace) => print((error as SpotifyException).message),
      );

  print('\nPodcast episode:');
  final episodes = spotify.shows.episodes('4AlxqGkkrqe0mfIx3Mi7Xt');
  await episodes.first().then((first) => print(first.items!.first)).onError(
        (error, stackTrace) => print((error as SpotifyException).message),
      );

  print('\nAlbum:');
  final album = await spotify.albums.get('2Hog1V8mdTWKhCYqI5paph');
  print(album.name);

  print('\nAlbum Tracks:');
  final tracks = await spotify.albums.getTracks(album.id!).all();
  for (final track in tracks) {
    print(track.name);
  }

  print("\nSearching for 'Metallica':");
  final search = await spotify.search.get('metallica').first(2);

  for (final pages in search) {
    if (pages.items == null) {
      print('Empty items');
    }

    for (final item in pages.items!) {
      if (item is PlaylistSimple) {
        print('Playlist: \n'
            'id: ${item.id}\n'
            'name: ${item.name}:\n'
            'collaborative: ${item.collaborative}\n'
            'href: ${item.href}\n'
            'itemslink: ${item.itemsLink!.href}\n'
            'owner: ${item.owner}\n'
            'public: ${item.owner}\n'
            'snapshotId: ${item.snapshotId}\n'
            'type: ${item.type}\n'
            'uri: ${item.uri}\n'
            'images: ${item.images!.length}\n'
            '-------------------------------');
      }
      if (item is Artist) {
        print('Artist: \n'
            'id: ${item.id}\n'
            'name: ${item.name}\n'
            'href: ${item.href}\n'
            'type: ${item.type}\n'
            'uri: ${item.uri}\n'
            '-------------------------------');
      }
      if (item is Track) {
        print('Track:\n'
            'id: ${item.id}\n'
            'name: ${item.name}\n'
            'href: ${item.href}\n'
            'type: ${item.type}\n'
            'uri: ${item.uri}\n'
            'isPlayable: ${item.isPlayable}\n'
            'artists: ${item.artists!.length}\n'
            'discNumber: ${item.discNumber}\n'
            'trackNumber: ${item.trackNumber}\n'
            'explicit: ${item.explicit}\n'
            '-------------------------------');
      }
      if (item is AlbumSimple) {
        print('Album:\n'
            'id: ${item.id}\n'
            'name: ${item.name}\n'
            'href: ${item.href}\n'
            'type: ${item.type}\n'
            'uri: ${item.uri}\n'
            'albumType: ${item.albumType}\n'
            'artists: ${item.artists!.length}\n'
            'images: ${item.images!.length}\n'
            'releaseDate: ${item.releaseDate}\n'
            'releaseDatePrecision: ${item.releaseDatePrecision}\n'
            '-------------------------------');
      }
    }
  }

  credentials = await spotify.getCredentials();
  print('\nCredentials:');
  print('Client Id: ${credentials.clientId}');
  print('Access Token: ${credentials.accessToken}');
  print('Credentials Expired: ${credentials.isExpired}');
}
