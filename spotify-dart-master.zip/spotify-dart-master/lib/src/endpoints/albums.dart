// Copyright (c) 2017, rinukkusu. All rights reserved. Use of this source code
// is governed by a BSD-style license that can be found in the LICENSE file.

part of '../../spotify.dart';

/// Endpoint for albums `v1/albums`
class Albums extends EndpointPaging {
  @override
  String get _path => 'v1/albums';

  Albums(super.api);

  /// Retrieves an album with its [albumId]
  Future<Album> get(String albumId) async {
    final jsonString = await _get('$_path/$albumId');
    final map = json.decode(jsonString);

    return Album.fromJson(map);
  }

  /// Returns the tracks of a given [albumId]
  @Deprecated('Use [tracks] instead')
  Pages<TrackSimple> getTracks(String albumId) => tracks(albumId);

  /// Returns the tracks of a given [albumId]
  Pages<TrackSimple> tracks(String albumId) =>
      _getPages('$_path/$albumId/tracks', (json) => TrackSimple.fromJson(json));
}
