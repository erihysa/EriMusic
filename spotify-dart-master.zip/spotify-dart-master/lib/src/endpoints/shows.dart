// Copyright (c) 2020, deandreamatias, rinukkusu. All rights reserved. Use of
// this source code is governed by a BSD-style license that can be found in the
// LICENSE file.

part of '../../spotify.dart';

/// Endpoint of shows `v1/shows`
class Shows extends EndpointPaging {
  @override
  String get _path => 'v1/shows';

  Shows(super.api);

  /// Get a single show
  ///
  /// [market]: An ISO 3166-1 alpha-2 country code or the string 'from_token'.
  /// If a country code is specified, only artists, albums, and tracks with
  /// content that is playable in that market is returned.
  Future<Show> get(String showId, {Market? market}) async {
    String jsonString;
    if (market != null) {
      final queryMap = {'market': market.name};
      final query = _buildQuery(queryMap);
      jsonString = await _get('$_path/$showId?$query');
    } else {
      jsonString = await _get('$_path/$showId');
    }

    final map = json.decode(jsonString);

    return Show.fromJson(map);
  }

  /// Get a Show's Episodes
  ///
  /// [market]: An ISO 3166-1 alpha-2 country code or the string 'from_token'.
  /// If a country code is specified, only artists, albums, and tracks with
  /// content that is playable in that market is returned.
  Pages<Episode> episodes(String showId, [Market? market]) {
    final query = _buildQuery({
      'market': market?.name,
    });
    final queryString = query.isNotEmpty ? '?$query' : '';

    return _getPages(
      '$_path/$showId/episodes$queryString',
      (json) => Episode.fromJson(json),
    );
  }
}
