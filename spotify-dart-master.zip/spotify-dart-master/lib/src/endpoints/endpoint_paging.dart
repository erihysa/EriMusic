// Copyright (c) 2017, 2018, hayribakici, chances. All rights reserved. Use of
// this source code is governed by a BSD-style license that can be found in the
// LICENSE file.

part of '../../spotify.dart';

typedef FilterFunction = bool Function(dynamic json);

// ignore: constant_identifier_names
const int _defaultPageLimit = 20;
// ignore: constant_identifier_names
const int _maximumPageLimit = 50;

/// Base class of all endpoints using pagination
abstract class EndpointPaging extends EndpointBase {
  EndpointPaging(super.api);

  Pages<T> _getPages<T>(
    String path,
    ParserFunction<T> pageItemParser, [
    String? pageKey,
    ParserFunction<Object>? pageContainerParser,
    FilterFunction? pageItemFilter,
    int defaultLimit = _defaultPageLimit,
    int maxLimit = _maximumPageLimit,
  ]) =>
      Pages(
        _api,
        path,
        pageItemParser,
        pageKey,
        pageContainerParser,
        pageItemFilter,
        defaultLimit,
        maxLimit,
      );

  CursorPages<T> _getCursorPages<T>(
    String path,
    ParserFunction<T> pageItemParser, [
    String? pageKey,
    ParserFunction<Object>? pageContainerParser,
    FilterFunction? pageItemFilter,
    int defaultLimit = _defaultPageLimit,
    int maxLimit = _maximumPageLimit,
  ]) =>
      CursorPages(
        _api,
        path,
        pageItemParser,
        pageKey,
        pageContainerParser,
        pageItemFilter,
        defaultLimit,
        maxLimit,
      );

  // ignore: unused_element
  BundledPages _getBundledPages<T>(
    String path,
    Map<String, ParserFunction<T>> pageItemParsers, [
    String? pageKey,
    ParserFunction<Object>? pageContainerParser,
    FilterFunction? pageItemFilter,
    int defaultLimit = _defaultPageLimit,
    int maxLimit = _maximumPageLimit,
  ]) =>
      BundledPages(_api, path, pageItemParsers, pageKey, pageContainerParser, pageItemFilter, defaultLimit, maxLimit);
}

/// Base class that represents a generic response page.
abstract class BasePage<T> {
  final BasePaging<T> _paging;
  Iterable<T>? _items;
  Object? _container;

  BasePage(
    this._paging,
    ParserFunction<T> pageItemParser, [
    Object? pageContainer,
    FilterFunction? pageItemFilter,
  ]) {
    final filteredItems = pageItemFilter != null ? _paging.itemsNative!.where(pageItemFilter) : _paging.itemsNative!;
    _items = filteredItems.map(pageItemParser);
    _container = pageContainer;
  }

  /// The offset-based paging object is a container for a set of objects. It
  /// contains a key called items (whose value is an array of the requested
  /// objects) along with other keys like previous, next and limit that can be
  /// useful in future calls.
  Paging<T> get metadata => _paging as Paging<T>;

  /// The requested data
  Iterable<T>? get items => _items;

  /// `true` if this page is the last page. `false` otherwise.
  bool get isLast;

  /// Generic next for multiple purposes for internal use only.
  /// It is not defined what data type it should have.
  /// Subclasses should return specific type and
  /// wrap another attribute with specific data type (e.g. [int]) around
  /// it. For example: `int get foo => _next as int`.
  ///
  /// Needs to be overridden by subclasses.
  @mustBeOverridden
  dynamic get _next;

  /// The object containing this page, if applicable
  Object? get container => _container;
}

@Deprecated('Use the [Page]\'s defaultLimit attribute instead')
const defaultLimit = 20;

/// A page that uses an offset to get to the next page.
class Page<T> extends BasePage<T> {
  Page(
    Paging<T> super._paging,
    super.pageItemParser, [
    super.pageContainer,
    super.pageItemFilter,
  ]);

  @override
  bool get isLast {
    final paging = _paging as Paging<T>;
    return (paging.offset ?? 0) + paging.limit >= paging.total;
  }

  @override
  dynamic get _next {
    final paging = _paging as Paging<T>;
    return (paging.offset ?? 0) + paging.limit;
  }

  /// Returns the offset for the next page.
  int get nextOffset => _next as int;
}

/// A page that uses a cursor to get to the next page
class CursorPage<T> extends BasePage<T> {
  CursorPage(
    CursorPaging<T> super._paging,
    super.pageItemParser, [
    super.pageContainer,
    super.pageItemFilter,
  ]);

  @override
  dynamic get _next => (_paging as CursorPaging<T>).cursors?.after ?? '';

  /// The cursor pointing to the next page.
  /// Is empty, when it's the last page.
  String get after => _next as String;

  @override
  bool get isLast => after.isEmpty;
}

/// Generic strategy for the next page
abstract class NextStrategy<T> {
  Future<T> _getPage(int limit, dynamic next);
}

abstract class _Pages<T> implements NextStrategy<T> {
  final SpotifyApiBase _api;
  final String _path;
  final String? _pageKey;
  final ParserFunction<dynamic>? _pageContainerParser;
  final FilterFunction? _pageItemFilter;
  late int _defaultLimit;
  final int _maxLimit;

  _Pages(
    this._api,
    this._path,
    this._pageKey,
    this._pageContainerParser,
    this._pageItemFilter, [
    this._defaultLimit = _defaultPageLimit,
    this._maxLimit = _maximumPageLimit,
  ]) {
    if (_pageKey != null && _pageContainerParser == null) {
      throw ArgumentError.notNull('pageContainerParser');
    } else if (_pageKey == null && _pageContainerParser != null) {
      throw ArgumentError.notNull('pageKey');
    }
    _ensureLimitWithinBoundaries(_defaultLimit);
  }

  int get defaultLimit => _defaultLimit;

  set defaultLimit(int value) {
    _ensureLimitWithinBoundaries(value);
    _defaultLimit = value;
  }

  int get maxLimit => _maxLimit;

  Future<T> first([int? limit]) {
    final resolvedLimit = limit ?? defaultLimit;
    _ensureLimitWithinBoundaries(resolvedLimit);
    return _getPage(resolvedLimit, null);
  }

  void _ensureLimitWithinBoundaries(int limit) {
    if (limit < 1 || _maxLimit < limit) {
      throw RangeError.range(limit, 1, _maxLimit, 'limit');
    }
  }

  int _resolveOffset(dynamic next) => next as int? ?? 0;

  String _resolveAfter(dynamic next) => next as String? ?? '';
}

/// Base class that handles retrieval of pages with one type
/// (e.g. [Artist], [Playlist] etc.)
abstract class SinglePages<T, V extends BasePage<T>> extends _Pages<V> implements NextStrategy<V> {
  bool _cancelled = false;
  final ParserFunction<T> _pageParser;
  final List<V> _bufferedPages = [];

  SinglePages(
    SpotifyApiBase api,
    String path,
    this._pageParser, [
    String? pageKey,
    ParserFunction<Object>? pageContainerMapper,
    FilterFunction? pageItemFilter,
    int defaultLimit = _defaultPageLimit,
    int maxLimit = _maximumPageLimit,
  ]) : super(
          api,
          path,
          pageKey,
          pageContainerMapper,
          pageItemFilter,
          defaultLimit,
          maxLimit,
        );

  Future<Iterable<T>> all([int? limit]) {
    return stream(limit ?? this.defaultLimit)
        .map((page) => page.items)
        .toList()
        .then((pages) => pages.expand((page) => page!));
  }

  Stream<V> stream([int? limit]) {
    late StreamController<V> stream;

    void handlePageAndGetNext(V page) {
      if (_cancelled) {
        stream.close();
        return;
      }

      if (stream.isPaused) {
        _bufferedPages.add(page);
      } else {
        stream.add(page);
      }

      // If this is the last page then end the stream
      if (page.isLast) {
        if (!stream.isPaused) {
          stream.close();
        }
        return;
      }

      // Otherwise get the next page
      _getPage(limit ?? this.defaultLimit, page._next).then(handlePageAndGetNext);
    }

    stream = StreamController<V>(
      onListen: () {
        _cancelled = false;
        Future<V> firstPage;
        if (_bufferedPages.isNotEmpty) {
          firstPage = Future.value(_bufferedPages.removeAt(0));
        } else {
          firstPage = first(limit);
        }
        firstPage.then(handlePageAndGetNext);
      },
      onCancel: () {
        _cancelled = true;
        return;
      },
      onResume: () {
        if (_bufferedPages.isEmpty) {
          return;
        }

        final isLastPage = _bufferedPages.last.isLast;
        _bufferedPages.forEach(stream.add);
        _bufferedPages.clear();

        if (isLastPage) {
          stream.close();
        }
      },
    );
    return stream.stream;
  }
}

/// Handles retrieval of a page through an offset
class Pages<T> extends SinglePages<T, Page<T>> {
  Pages(
    super.api,
    super.path,
    super.pageParser, [
    super.pageKey,
    super.pageContainerMapper,
    super.pageItemFilter,
    super.defaultLimit,
    super.maxLimit,
  ]);

  Pages.fromPaging(
    SpotifyApiBase api,
    Paging<T> paging,
    ParserFunction<T> pageParser, [
    String? pageKey,
    ParserFunction<Object>? pageContainerMapper,
    FilterFunction? pageItemFilter,
    int defaultLimit = _defaultPageLimit,
    int maxLimit = _maximumPageLimit,
  ]) : super(
          api,
          Uri.parse(paging.href!).path.substring(1),
          pageParser,
          pageKey,
          pageContainerMapper,
          pageItemFilter,
          defaultLimit,
          maxLimit,
        ) {
    _bufferedPages.add(Page<T>(paging, _pageParser, null, _pageItemFilter));
  }

  @override
  Future<Page<T>> _getPage(int limit, [dynamic next]) => getPage(limit, _resolveOffset(next));

  Future<Page<T>> getPage(int limit, [int offset = 0]) async {
    _ensureLimitWithinBoundaries(limit);
    final pathDelimiter = _path.contains('?') ? '&' : '?';
    final newPath = '$_path${pathDelimiter}limit=$limit&offset=$offset';

    final jsonString = await _api._get(newPath);
    final map = json.decode(jsonString);

    if (_pageContainerParser == null) {
      final paging = Paging<T>.fromJson(map);
      return Page<T>(paging, _pageParser, null, _pageItemFilter);
    } else {
      final paging = Paging<T>.fromJson(map[_pageKey]);
      final container = _pageContainerParser!(map);
      return Page<T>(paging, _pageParser, container, _pageItemFilter);
    }
  }
}

/// Handles retrieval of a page through a cursor
class CursorPages<T> extends SinglePages<T, CursorPage<T>> {
  CursorPages(
    super.api,
    super.path,
    super.pageParser, [
    super.pageKey,
    super.pageContainerMapper,
    super.pageItemFilter,
    super.defaultLimit,
    super.maxLimit,
  ]);

  CursorPages.fromCursorPaging(
    SpotifyApiBase api,
    CursorPaging<T> paging,
    ParserFunction<T> pageParser, [
    String? pageKey,
    ParserFunction<Object>? pageContainerMapper,
    FilterFunction? pageItemFilter,
    int defaultLimit = _defaultPageLimit,
    int maxLimit = _maximumPageLimit,
  ]) : super(
          api,
          Uri.parse(paging.href!).path.substring(1),
          pageParser,
          pageKey,
          pageContainerMapper,
          pageItemFilter,
          defaultLimit,
          maxLimit,
        ) {
    _bufferedPages.add(CursorPage<T>(paging, _pageParser, null, _pageItemFilter));
  }

  @override
  Future<CursorPage<T>> _getPage(int limit, [dynamic next]) => getPage(limit, _resolveAfter(next));

  Future<CursorPage<T>> getPage(int limit, [String after = '']) async {
    _ensureLimitWithinBoundaries(limit);
    final pathDelimiter = _path.contains('?') ? '&' : '?';
    var newPath = '$_path${pathDelimiter}limit=$limit';
    if (after.isNotEmpty) {
      newPath += '&after=$after';
    }

    final jsonString = await _api._get(newPath);
    final map = json.decode(jsonString);

    if (_pageContainerParser == null) {
      final paging = CursorPaging<T>.fromJson(map);
      return CursorPage<T>(paging, _pageParser, null, _pageItemFilter);
    } else {
      final paging = CursorPaging<T>.fromJson(map[_pageKey]);
      final container = _pageContainerParser!(map);
      return CursorPage<T>(paging, _pageParser, container, _pageItemFilter);
    }
  }
}

/// Page that allows multiple types (artist, track, episode etc.) together
class BundledPages extends _Pages<List<Page<dynamic>>> {
  final Map<String, ParserFunction<dynamic>> _pageMappers;

  BundledPages(
    SpotifyApiBase api,
    String path,
    this._pageMappers, [
    String? pageKey,
    ParserFunction<dynamic>? pageContainerParser,
    FilterFunction? pageItemFilter,
    int defaultLimit = _defaultPageLimit,
    int maxLimit = _maximumPageLimit,
  ]) : super(
          api,
          path,
          pageKey,
          pageContainerParser,
          pageItemFilter,
          defaultLimit,
          maxLimit,
        );

  @override
  Future<List<Page<dynamic>>> _getPage(int limit, [dynamic next]) async => getPage(limit, _resolveOffset(next));

  Future<List<Page<dynamic>>> getPage(int limit, [int offset = 0]) async {
    _ensureLimitWithinBoundaries(limit);
    final pathDelimiter = _path.contains('?') ? '&' : '?';
    final path = '$_path${pathDelimiter}limit=$limit&offset=$offset';

    return _api._get(path).then(_parseBundledPage);
  }

  List<Page<dynamic>> _parseBundledPage(String jsonString) {
    final map = json.decode(jsonString);
    final pages = <Page<dynamic>>[];
    _pageMappers.forEach((key, value) {
      if (map[key] != null) {
        final paging = Paging.fromJson(map[key]);
        Page page;
        if (_pageContainerParser == null) {
          page = Page(paging, value, null, _pageItemFilter);
        } else {
          final container = _pageContainerParser!(map[key]);
          page = Page(paging, value, container, _pageItemFilter);
        }
        pages.add(page);
      }
    });
    return pages;
  }
}
