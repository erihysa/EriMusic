// Copyright (c) 2017, 'rinukkusu'. All rights reserved. Use of this source code
// is governed by a BSD-style license that can be found in the LICENSE file.

part of '../spotify.dart';

abstract class SpotifyApiBase {
  static const String _baseUrl = 'https://api.spotify.com';
  static const String _tokenUrl = 'https://accounts.spotify.com/api/token';
  static const String _authorizationUrl = 'https://accounts.spotify.com/authorize';

  bool _shouldWait = false;

  late SpotifyClient _spotifyClient;
  SpotifyClient get spotifyClient => _spotifyClient;

  @visibleForTesting
  FutureOr<oauth2.Client> get client => _spotifyClient._inner;

  late Artists _artists;
  Artists get artists => _artists;

  late Albums _albums;
  Albums get albums => _albums;

  late Audiobooks _audiobooks;
  Audiobooks get audiobooks => _audiobooks;

  late Chapters _chapters;
  Chapters get chapters => _chapters;

  late Tracks _tracks;
  Tracks get tracks => _tracks;

  late Playlists _playlists;
  Playlists get playlists => _playlists;

  late Episodes _episodes;
  Episodes get episodes => _episodes;

  late Search _search;
  Search get search => _search;

  late Me _me;
  Me get me => _me;

  late PlayerEndpoint _player;
  PlayerEndpoint get player => _player;

  late Shows _shows;
  Shows get shows => _shows;

  SpotifyApiBase.fromClient(FutureOr<oauth2.Client> client) {
    _spotifyClient = SpotifyClient(client);
    _player = PlayerEndpoint(this);
    _me = Me(this);

    _artists = Artists(this);
    _albums = Albums(this);
    _audiobooks = Audiobooks(this);
    _chapters = Chapters(this);
    _tracks = Tracks(this);
    _episodes = Episodes(this);
    _playlists = Playlists(this);

    _search = Search(this);
    _shows = Shows(this);
  }

  SpotifyApiBase(
    SpotifyApiCredentials credentials, [
    http.Client? httpClient,
    Function(SpotifyApiCredentials)? callBack,
  ]) : this.fromClient(_getOauth2Client(credentials, httpClient, callBack));

  SpotifyApiBase.fromAuthCodeGrant(
    oauth2.AuthorizationCodeGrant grant,
    String responseUri,
  ) : this.fromClient(
          grant.handleAuthorizationResponse(
            Uri.parse(responseUri).queryParameters,
          ),
        );

  SpotifyApiBase._withAccessToken(String accessToken) : this.fromClient(oauth2.Client(oauth2.Credentials(accessToken)));

  static Future<SpotifyApi> _asyncFromCredentials(
    SpotifyApiCredentials credentials, [
    http.Client? httpClient,
    Function(SpotifyApiCredentials)? callBack,
  ]) async {
    final client = await _getOauth2Client(
      credentials,
      httpClient,
      callBack,
    );

    return SpotifyApi.fromClient(client);
  }

  static oauth2.AuthorizationCodeGrant authorizationCodeGrant(
    SpotifyApiCredentials credentials,
    http.Client httpClient, {
    String? codeVerifier,
    Function(SpotifyApiCredentials)? onCredentialsRefreshed,
  }) {
    // Use codeVerifier from parameter, or fall back to credentials
    final verifier = codeVerifier ?? credentials.codeVerifier;

    return oauth2.AuthorizationCodeGrant(
      credentials.clientId!,
      Uri.parse(SpotifyApiBase._authorizationUrl),
      Uri.parse(SpotifyApiBase._tokenUrl),
      secret: credentials.clientSecret,
      codeVerifier: verifier,
      httpClient: httpClient,
      onCredentialsRefreshed: onCredentialsRefreshed != null
          ? (oauth2.Credentials cred) {
              final newCredentials = SpotifyApiCredentials(
                credentials.clientId,
                credentials.clientSecret,
                accessToken: cred.accessToken,
                expiration: cred.expiration,
                refreshToken: cred.refreshToken,
                scopes: cred.scopes,
                codeVerifier: verifier,
              );
              onCredentialsRefreshed(newCredentials);
            }
          : null,
    );
  }

  static FutureOr<oauth2.Client> _getOauth2Client(
    SpotifyApiCredentials credentials,
    http.Client? httpClient, [
    Function(SpotifyApiCredentials)? callBack,
  ]) async {
    if (credentials.fullyQualified) {
      var oauthCredentials = credentials._toOauth2Credentials();

      void credentialRefreshedWrapperCallback(oauth2.Credentials cred) {
        callBack?.call(
          SpotifyApiCredentials(
            credentials.clientId,
            credentials.clientSecret,
            accessToken: cred.accessToken,
            expiration: cred.expiration,
            refreshToken: cred.refreshToken,
            scopes: cred.scopes,
            codeVerifier: credentials.codeVerifier,
          ),
        );
      }

      if (oauthCredentials.isExpired) {
        oauthCredentials = await oauthCredentials.refresh(
          identifier: credentials.clientId,
          secret: credentials.clientSecret,
          httpClient: httpClient,
        );
        credentialRefreshedWrapperCallback(oauthCredentials);
      }

      return oauth2.Client(
        oauthCredentials,
        identifier: credentials.clientId,
        onCredentialsRefreshed: credentialRefreshedWrapperCallback,
        secret: credentials.clientSecret,
      );
    }

    return oauth2.clientCredentialsGrant(
      Uri.parse(SpotifyApiBase._tokenUrl),
      credentials.clientId,
      credentials.clientSecret,
      httpClient: httpClient,
    );
  }

  /// [enable]s logging of the requests and responses on the debug console.
  /// [loggingDetail] controls the logging verbosity. Default's set
  /// to [LoggingDetail.simple].
  /// If required [logger] is also possible for e.g. saving logs into a file
  /// etc.
  void enableLogging({
    required bool enable,
    LoggingDetail loggingDetail = LoggingDetail.simple,
    SpotifyLogger? logger,
  }) {
    _spotifyClient.enableLogging = enable;
    _spotifyClient.loggingDetail = loggingDetail;
    _spotifyClient.logger = logger;
  }

  set loggingDetail(LoggingDetail value) {
    if (_spotifyClient._enableLogging) {
      _spotifyClient.loggingDetail = value;
    }
  }

  /// Expands shortened spotify [url]
  Future<String> expandLink(String url) async => _streamedHeadImpl(url, const {});

  Future<String> _get(String path) {
    return _getImpl('$_baseUrl/$path', const {});
  }

  Future<String> _post(String path, [String body = '']) {
    return _postImpl('$_baseUrl/$path', const {}, body);
  }

  Future<String> _delete(String path, [String body = '']) {
    return _deleteImpl('$_baseUrl/$path', const {}, body);
  }

  Future<String> _put(String path, [String? body]) {
    return _putImpl('$_baseUrl/$path', const {}, body);
  }

  Future<String> _streamedHeadImpl(
    String url,
    Map<String, String> headers,
  ) async {
    return await _requestWrapper(() async {
      final request = http.Request('HEAD', Uri.parse(url));
      request.headers.addAll(headers);
      return _spotifyClient.send(request);
    });
  }

  Future<String> _getImpl(String url, Map<String, String> headers) async {
    return await _requestWrapper(
      () async => await _spotifyClient.get(Uri.parse(url), headers: headers),
    );
  }

  Future<String> _postImpl(
    String url,
    Map<String, String> headers,
    dynamic body,
  ) async {
    return await _requestWrapper(
      () async => await _spotifyClient.post(
        Uri.parse(url),
        headers: headers,
        body: body,
      ),
    );
  }

  Future<String> _deleteImpl(
    String url,
    Map<String, String> headers,
    body,
  ) async {
    return await _requestWrapper(() async {
      final request = http.Request('DELETE', Uri.parse(url));
      request.headers.addAll(headers);
      request.body = body;
      return await http.Response.fromStream(await _spotifyClient.send(request));
    });
  }

  Future<String> _putImpl(
    String url,
    Map<String, String> headers,
    dynamic body,
  ) async {
    return await _requestWrapper(
      () async => await _spotifyClient.put(
        Uri.parse(url),
        headers: headers,
        body: body,
      ),
    );
  }

  // the reason we are using [http.BaseResponse] is because
  // otherwise we wouldn't be able to access the redirect url from
  // BaseResponseWithUrl
  Future<String> _requestWrapper(
    Future<http.BaseResponse> Function() request, {
    int retryLimit = 5,
  }) async {
    for (var i = 0; i < retryLimit; i++) {
      while (_shouldWait) {
        await Future.delayed(const Duration(milliseconds: 500));
      }
      try {
        final response = await request();

        // distinguish between url redirect responses and body responses
        // note, that any response that also contains a redirect url
        // will be chosen instead of its body contents
        // FIXME: in future releases of http2, the url is a part of the
        //  [http.Response] type
        if (response case http.BaseResponseWithUrl(:final url)) {
          return url.toString();
        }
        return handleResponseWithBody(response as http.Response);
      } on ApiRateException catch (ex) {
        if (i == retryLimit - 1) rethrow;
        print(
          'Spotify API rate exceeded. waiting for ${ex.retryAfter} seconds',
        );
        _shouldWait = true;
        unawaited(
          Future.delayed(Duration(seconds: ex.retryAfter.toInt())).then((v) => _shouldWait = false),
        );
      }
    }
    throw SpotifyException('Could not complete request');
  }

  Future<SpotifyApiCredentials> getCredentials() async {
    return SpotifyApiCredentials._fromClient(await client);
  }

  String handleResponseWithBody(http.Response response) {
    final responseBody = utf8.decode(response.bodyBytes);
    if (response.statusCode >= 400) {
      final jsonMap = json.decode(responseBody);
      final error = SpotifyError.fromJson(jsonMap['error']);
      if (response.statusCode == 429) {
        if (error.reason == SpotifyErrorReason.quotaExceeded) {
          throw ApiQuotaException.fromSpotify(error);
        }
        final retryAfter = num.tryParse(response.headers['retry-after'] ?? '');
        if (retryAfter != null && retryAfter.isFinite && retryAfter >= 0) {
          throw ApiRateException.fromSpotify(error, retryAfter);
        }
      }
      throw SpotifyException.fromSpotify(
        error,
      );
    }
    return responseBody;
  }
}
