import 'dart:async';

import 'spotify_mock.dart';
import 'package:test/test.dart';
import 'package:spotify/spotify.dart';

Future main() async {
  final spotify = SpotifyApiMock.create();

  tearDown(() {
    spotify.interceptor = null;
  });

  group('User', () {
    test('currentlyPlaying', () async {
      final result = await spotify.player.currentlyPlaying();

      expect(result.item!.name, 'As I Am');
    });

    test('Devices', () async {
      final result = await spotify.player.devices();
      expect(result.length, 2);
      expect(result.first.id, '5fbb3ba6aa454b5534c4ba43a8c7e8e45a63ad0e');
      expect(result.first.isActive, true);
      expect(result.first.isRestricted, true);
      expect(result.first.isPrivateSession, true);
      expect(result.first.name, 'My fridge');
      expect(result.first.type, DeviceType.Computer);
      expect(result.first.volumePercent, 100);

      // the second entry does not have a valid [DeviceType],
      // and should have `Unknown` instead.
      expect(result.last.type, DeviceType.Unknown);
    });

    test('recentlyPlayed', () async {
      // the parameters don't do anything. They are just dummies
      final result = await spotify.me.recentlyPlayed(limit: 3, before: DateTime.now()).all();
      expect(result.length, 2);
      final first = result.first;
      expect(first.track != null, true);

      // just testing some sample attributes
      final firstTrack = first.track;
      expect(firstTrack!.durationMs, 108546);
      expect(firstTrack.explicit, false);
      expect(firstTrack.id, '2gNfxysfBRfl9Lvi9T3v6R');
      expect(firstTrack.artists!.length, 1);
      expect(firstTrack.artists!.first.name, 'Tame Impala');

      // test album fields (Track instead of TrackSimple)
      expect(firstTrack.album != null, true);
      expect(firstTrack.album!.name, 'Currents');
      expect(firstTrack.album!.id, '79dL7FLiJFOO0EoehUHQBv');

      final second = result.last;
      expect(second.playedAt, DateTime.tryParse('2016-12-13T20:42:17.016Z'));
      expect(second.context!.uri, 'spotify:artist:5INjqkS1o8h1imAzPqGZBb');
    });

    test('getQueue', () async {
      final result = await spotify.player.queue();
      final currentlyPlaying = result.currentlyPlaying;
      final queue = result.queue;

      expect(currentlyPlaying, isNotNull);
      expect(queue, isNotNull);

      // Checking the currentlyPlaying data

      expect(currentlyPlaying!.name, 'string');

      // Checking the queue data

      expect(queue!.length == 1, true);
      expect(queue.first.name, 'string');
    });

    test('following', () async {
      final result = spotify.me.following(FollowingType.artist);

      final first = await result.first();
      expect(first.items!.length, 1);

      final firstArtist = first.items!.first;
      expect(firstArtist.name, 'Afasi & Filthy');
      expect(first.after, '0aV6DOiouImYTqrR5YlIqx');
    });

    group('me/top', () {
      test('tracks', () async {
        final result = await spotify.me.topTracks().first();
        expect(result.items?.length, 2);

        final firstItem = result.items?.first;
        expect(firstItem?.album?.albumType, AlbumType.album);
        expect(firstItem?.album?.name, 'Ali');
        expect(firstItem?.album?.uri, 'spotify:album:4dfAJiDQHQf4dGX0ZdtxPh');
        expect(firstItem?.artists?.length, 2);
        expect(firstItem?.artists?.first.name, 'Vieux Farka Touré');
      });

      test('artists', () async {
        final result = await spotify.me.topArtists().first();
        expect(result.items?.length, 2);

        final firstItem = result.items?.first;
        expect(firstItem?.name, 'Porcupine Tree');
      });
    });
    group('me/shows', () {
      test('savedShows', () async {
        final pages = spotify.me.shows.saved();
        final result = await pages.first(2);
        expect(result.items!.length, 2);

        final firstShow = result.items!.first;
        expect(firstShow.type, 'show');
        expect(firstShow.name != null, true);
        expect(firstShow.id, '4XPl3uEEL9hvqMkoZrzbx5');
      });

      test('containsShows', () async {
        final response = await spotify.me.library.contains([ShowUri('123'), ShowUri('456'), ShowUri('789')]);
        expect(response.isNotEmpty, true);
        expect(response[ShowUri('123')], true);
        expect(response[ShowUri('456')], false);
      });

      test('shows.remove includes market query param', () async {
        spotify.interceptor = (method, url, headers, [body]) {
          expect(url, contains(Uri.encodeComponent(ShowUri('s1').toString())));
          return null;
        };
        await spotify.me.library.remove([ShowUri('s1')]);
      });
    });

    group('me/episodes', () {
      test('savedEpisodes', () async {
        final pages = spotify.me.episodes.saved();
        final result = await pages.first(2);
        expect(result.items!.length, 1);

        final firstEpisode = result.items!.first;
        expect(firstEpisode.type, 'episode');
        expect(firstEpisode.name, isNotNull);
        expect(firstEpisode.id, '5Xt5DXGzch68nYYamXrNxZ');
        expect(firstEpisode.show, isNotNull);
      });

      test('containsSavedEpisodes', () async {
        final episodeIds = [
          EpisodeUri('5Xt5DXGzch68nYYamXrNxZ'),
          EpisodeUri('1A2GTWGtFfWp7KSQTwWOyo'),
          EpisodeUri('2noRn2Aes5aoNVsU6iWThc'),
        ];

        final list = await spotify.me.library.contains(episodeIds);

        expect(list.length, 3);
        expect(list[episodeIds[0]], true);
        expect(list[episodeIds[1]], false);
        expect(list[episodeIds[2]], true);
      });
    });

    group('me/audiobooks', () {
      test('saved audiobooks', () async {
        final pages = spotify.me.audiobooks.saved();
        final result = await pages.first();

        expect(result.items, isNotNull);
        expect(result.items!.length, 1);

        final saved = result.items!.first;
        expect(saved.addedAt, isNotNull);
        expect(saved.audiobook, isNotNull);
        expect(saved.audiobook!.id, 'savedbook');
        expect(saved.audiobook!.name, 'Saved Audiobook');
        expect(saved.audiobook!.type, 'audiobook');
      });

      test('contains audiobooks', () async {
        final result = await spotify.me.library
            .contains([AudiobookUri('audiobook1'), AudiobookUri('audiobook2'), AudiobookUri('audiobook3')]);

        expect(result.isNotEmpty, true);
        expect(result.length, 3);
        expect(result[AudiobookUri('audiobook1')], true);
        expect(result[AudiobookUri('audiobook2')], false);
        expect(result[AudiobookUri('audiobook3')], true);
      });

      test('contains throws on empty list', () async {
        expect(
          () => spotify.me.library.contains([]),
          throwsA(isA<ArgumentError>()),
        );
      });

      test('contains throws on >50 ids', () async {
        final tooManyIds = List.generate(51, (i) => TrackUri('id$i'));
        expect(
          () => spotify.me.library.contains(tooManyIds),
          throwsA(isA<RangeError>()),
        );
      });

      test('save throws on empty list', () async {
        expect(
          () => spotify.me.library.save([]),
          throwsA(isA<ArgumentError>()),
        );
      });

      test('save throws on >50 ids', () async {
        final tooManyIds = List.generate(51, (i) => TrackUri('id$i'));
        expect(
          () => spotify.me.library.save(tooManyIds),
          throwsA(isA<RangeError>()),
        );
      });

      test('remove throws on empty list', () async {
        expect(
          () => spotify.me.library.remove([]),
          throwsA(isA<ArgumentError>()),
        );
      });

      test('remove throws on >50 ids', () async {
        final tooManyIds = List.generate(51, (i) => TrackUri('id$i'));
        expect(
          () => spotify.me.library.remove(tooManyIds),
          throwsA(isA<RangeError>()),
        );
      });
    });
  });

  group('me/tracks', () {
    test('containsTracks', () async {
      final result = await spotify.me.library.contains([TrackUri('1'), TrackUri('2'), TrackUri('3')]);

      expect(result.length, 3);
      expect(result[TrackUri('1')], isTrue);
      expect(result[TrackUri('2')], isFalse);
      expect(result[TrackUri('3')], isTrue);
    });
  });
}
